

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog5121.poe;

/**
 *
 * @author Michelle
 */
public class Login {
    
    //creating methods
    
    public boolean checkUserName(String userName){
        boolean underscore=false;
        for (int i=0;i<userName.length();i++){
            if ('_'==userName.charAt(i)){
                underscore=true;
            }
         }
        if (underscore==true && userName.length()<=5){
            return true;
        }
        else{
            return false;
        }
        
    }
     public boolean checkPassWordComplexity(String password){
         boolean cap=false;
         boolean number=false;
        boolean specialChar=false;
         for (int i=0;i<password.length();i++){
            if ((int)password.charAt(i)>=65 && (int)password.charAt(i)<=90 ){
                cap=true;
            }
            else if ((int)password.charAt(i)>=48 && (int)password.charAt(i)<=57){
                number=true;
            }
          else if(((int)password.charAt(i)>=33 && (int)password.charAt(i)<=47) || ((int)password.charAt(i)>=58 && (int)password.charAt(i)<=64) || ((int)password.charAt(i)>=91 && (int)password.charAt(i)<=96 || ((int)password.charAt(i)>=123 && (int)password.charAt(i)<=126))){
                specialChar=true;
            }
         }
         if (cap==true && number==true && specialChar==true && password.length()>=8){
             return true;
         }
         else{
             return false;
         }
         
     }
     
     public String registerUser(String username, String password){
       
         if(checkUserName( username)==false && checkPassWordComplexity(password)==true){
             return "The username is incorrectly formatted";
         }
         else if (checkPassWordComplexity(password)==false && checkUserName( username)==true ){
             return "The password does not meet the complexity requirements.";
         }
         else{
             return "The user has been registered successfully.";
         }
     }
     
     public boolean loginUser(String username, String password, String loginUsername, String loginPassword){
         if(username.equals(loginUsername) && password.equals(loginPassword)){
              return true;
         }
         
         
         else{
             return false;
         }
        
     }
     public String returnLoginStatus(String first,String last,String username, String password, String loginUsername, String loginPassword){
         if (loginUser(username,password,loginUsername,loginPassword)==true){
             return "Welcome "+first+" "+last+" it is great to see you again";
         }
         
         else{
             return "Username or password incorrect, please try again";
         }
     
     }
}