/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog5121.poe;

import javax.swing.JOptionPane;
import java.util.Scanner;

/**
 *
 * @author Michelle
 */
public class PROG5121POE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Login status=new Login();
        Task task=new Task();
        
        JOptionPane.showMessageDialog(null," Welcome to the Registration Feature");
        
       String firstName=JOptionPane.showInputDialog(null,"Please enter your First Name ");
       
         String lastName=JOptionPane.showInputDialog(null,"Please enter your Last Name ");
        
        
        //Prompting the user
        
         String regUsername=JOptionPane.showInputDialog(null,"Please enter your Username");
        
        
         String regPassword=JOptionPane.showInputDialog(null,"Please enter your Password ");
        
        

        boolean reg=false;
        while(reg==false){
            if (status.checkUserName( regUsername)==true && status.checkPassWordComplexity(regPassword)==true){
                JOptionPane.showMessageDialog(null,status.registerUser(regUsername, regPassword));
                reg=true;
                JOptionPane.showMessageDialog(null," Username and password has been successfully captured");
               
            }
            else if (status.checkUserName( regUsername)==false && status.checkPassWordComplexity(regPassword)==true){
                JOptionPane.showMessageDialog(null,status.registerUser(regUsername, regPassword));
                 JOptionPane.showMessageDialog(null,"Username is in an incorrect format, please ensure that your username contains an underscore and is no more than 5 characters in length");
                  regUsername=JOptionPane.showInputDialog(null,"Please enter your Username");
                
                
            }
            else if(status.checkUserName( regUsername)==true && status.checkPassWordComplexity(regPassword)==false){
                JOptionPane.showMessageDialog(null,status.registerUser(regUsername, regPassword));
                 JOptionPane.showMessageDialog(null,"Password is in an incorrect format, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character. ");
                 regPassword=JOptionPane.showInputDialog(null,"Please enter your Password");
            }
            else{
                 JOptionPane.showMessageDialog(null,status.registerUser(regUsername, regPassword));
             
                  regUsername=JOptionPane.showInputDialog(null,"Please enter your Userame");
                 
                 regPassword=JOptionPane.showInputDialog(null,"Please enter your Password");
                  
            }
            
        
        }
        System.out.println(status.registerUser(regUsername, regPassword));
        JOptionPane.showMessageDialog(null,"Welcome to the Login Feature");
        
       String logUsername= JOptionPane.showInputDialog(null,"Please enter your username to login");
        
        
        String logPassword=JOptionPane.showInputDialog(null,"Please enter your password to login");
        boolean log=false;
        int count=0;
        int select;
        Scanner sc=new Scanner(System.in);
        while(!log){
        if (regUsername.equals(logUsername) && regPassword.equals(logPassword)){
            JOptionPane.showMessageDialog(null,status.returnLoginStatus(firstName,lastName,regUsername, regPassword,logUsername,logPassword));
            
            log=true;
        }
        else if(!(regUsername.equals(logUsername)) && regPassword.equals(logPassword)){
             JOptionPane.showMessageDialog(null,status.returnLoginStatus(firstName,lastName,regUsername, regPassword,logUsername,logPassword));
            
             logUsername=JOptionPane.showInputDialog(null,"Your username is incorrect, please enter the correct username to login");
        }
        else if(!(regPassword.equals(logPassword)) && regUsername.equals(logUsername)){
             JOptionPane.showMessageDialog(null,status.returnLoginStatus(firstName,lastName,regUsername, regPassword,logUsername,logPassword));
            
             logPassword= JOptionPane.showInputDialog(null,"Your password is incorrect, please enter the correct password to login");
        }
        else{
              JOptionPane.showMessageDialog(null,status.returnLoginStatus(firstName,lastName,regUsername, regPassword,logUsername,logPassword));
       
         logUsername= JOptionPane.showInputDialog(null,"Your username is incorrect, please enter the correct username to login");
        
        logPassword=JOptionPane.showInputDialog(null,"Your password is incorrect, please enter the correct password to login");
        }
        count++;
        if(count==3){
            JOptionPane.showMessageDialog(null,"Account restricted");
            break;
        }
        }
        
        
            if (regUsername.equals(logUsername) && regPassword.equals(logPassword)){
            select=Integer.parseInt(JOptionPane.showInputDialog(null,"Welcome to EasyKanBan \nSelect between the following \n  Option 1) Add tasks \n  Option 2) Show-report \n  Option 3) Quit"));
            while(select!=3){
            if (select==1){
                
            
            int taskNumber=Integer.parseInt(JOptionPane.showInputDialog(null,"How many tasks would you like to add"));
            String[] devName=new String[taskNumber];
            String[] devSurname=new String[taskNumber];
            String[] taskName=new String[taskNumber];
            int[] taskDuration=new int[taskNumber];
            String[] taskID=new String[taskNumber];
            String[] taskStatus=new String[taskNumber];
            String taskDescription="";
            int taskCount;
            int status1;
            for(int i=0;i<taskNumber;i++){
               
                
                taskCount=i;
                 taskName[i]=JOptionPane.showInputDialog(null,"Please enter the Task Name:");
                
                taskDescription=JOptionPane.showInputDialog(null,"Please enter the Task Description: ");
             
                //adding on the arrayList
               
                boolean s=task.checkTaskDescription(taskDescription);
                if(!s){
                     JOptionPane.showMessageDialog(null,"Your task description has more than 50 characters");
                }
                
                 devName[i]=JOptionPane.showInputDialog(null,"Please enter the Developer Name:");
                 
                
              devSurname[i]=JOptionPane.showInputDialog(null," Enter the Developer Surname:");
                
                taskDuration[i]=Integer.parseInt(JOptionPane.showInputDialog(null," Enter the Task Duration:"));
                task.total+=taskDuration[i];
                
                
               //Task ID
               taskID[i]=task.createTaskID(taskName[i], devName[i]);
               
                
                status1=Integer.parseInt(JOptionPane.showInputDialog(null,"Select the task status: \n  Option 1) To Do \n  Option 2) Done \n  Option 3) Doing"));
                if (status1==1){
                    taskStatus[i]="To Do";
                }
                else if (status1==2){
                    taskStatus[i]="Done";
                }
                else{
             taskStatus[i]="Doing";
                }
              
             JOptionPane.showMessageDialog(null,task.printTaskDetails(taskStatus[i], devName[i],devSurname[i], taskName[i], taskDescription, taskID[i], taskDuration[i]));
            task.taskNumber+=1;
            
            }
            ShowReport.devName=devName;
            ShowReport.duration=taskDuration;
            ShowReport.taskName=taskName;
            ShowReport.taskID=taskID;
            ShowReport.taskStatus=taskStatus;
            
            JOptionPane.showMessageDialog(null,"The total hours \n"+task.returnTotalHours());
            
            }
            else if(select==2){
                JOptionPane.showMessageDialog(null,"Coming soon");
                
                boolean t=true;
                while(t){
                int value=Integer.parseInt(JOptionPane.showInputDialog(null, " Option 1) Display the Developer, Task Names and Task Duration for all tasks with the status of done.\n "
                        + " Option 2) Display the Developer and Duration of the class with the longest duration. \n"
                        + " Option 3) Search for a task with a Task Name and display the Task Name, Developer and Task Status. \n"
                        + " Option 4) Search for all tasks assigned to a developer and display the Task Name and Task Status. \n"
                        + " Option 5) Delete a task using the Task Name. \n"
                        + " Option 6) Display a report that lists the full details of all captured tasks. \n"
                        + " Option 7) Exit"));
                    switch (value) {
                        case 1:
                            JOptionPane.showMessageDialog(null,ShowReport.statusOfDone());
                            break;
                        case 2:
                            JOptionPane.showMessageDialog(null, ShowReport.longestDuration());
                            break;
                        case 3:
                            String name=JOptionPane.showInputDialog(null, "Please enter the name of the task you want to search");
                            JOptionPane.showMessageDialog(null,ShowReport.searchTaskName(name));
                            break;
                        case 4:
                            String developer=JOptionPane.showInputDialog(null, "Please enter the name of the developer you want to search");
                            JOptionPane.showMessageDialog(null,ShowReport.searchDeveloper(developer));
                            break;
                        case 5:
                            name=JOptionPane.showInputDialog(null, "Please enter the name of the task you want to delete");
                            ShowReport.delete(name);
                            break;
                        case 6:
                            JOptionPane.showMessageDialog(null,ShowReport.fullReport());
                            break;
                        default:
                            t=false;
                            break;
                    }
            }
            }
            else{
                JOptionPane.showMessageDialog(null,"Thank you,bye");
                
                System.exit(0);
            }
            select=Integer.parseInt(JOptionPane.showInputDialog(null,"Welcome to EasyKanBan \nPlease choose one of the following \n a. Option 1) Add tasks \n b. Option 2) Show-report \n c. Option 3) Quit"));
            }
            
            //status of done
            
            
            //Duration 
            
           
            }
    }
    
}

          
       