/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login_and_register;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
/**
 *
 * @author Michelle
 */
public class Login_and_Register {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        // setting the frame visible
       Login login = new Login();
        login.setVisible(true);
        
                
        
    }
    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {                                                
        int password = 8;
        if (password < 0){
            System.out.println("the password is negative.");
        }
    }        
}
