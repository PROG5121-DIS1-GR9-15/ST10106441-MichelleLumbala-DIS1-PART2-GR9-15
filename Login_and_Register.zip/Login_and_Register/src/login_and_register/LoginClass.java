/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login_and_register;
import java.util.Random;

/**
 *
 * @author Michelle
 */
public class LoginClass {
  
    //creating method
 boolean checkUserName(){
    
    System.out.println(checkUserName(5));
   
     return false;
        
    }
private static char[] checkUserName(int length){
    String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
    String specialCharacter = "_!@#";
    String numbers = "1234567890";
   String combinedChars = capitalCaseLetters + lowerCaseLetters + numbers + specialCharacter ;
   Random random = new Random();
    char[] username = new char[length];
    
     username[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
    username[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
    username[2] = specialCharacter.charAt(random.nextInt(specialCharacter.length()));
    username[3] = numbers.charAt(random.nextInt(numbers.length()));
    
    for(int i = 5; i< length; i++){
        username[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
    }
    return username;
      
}   




 boolean checkPasswordComplexity(){
    System.out.println(checkPasswordComplexity(8));
    return false;
}
private static char[] checkPasswordComplexity(int length){
    String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
    String numbers = "1234567890";
    String specialCharacter = "!@#$";
    String combinedChars = capitalCaseLetters + lowerCaseLetters + numbers + specialCharacter ;
    Random random = new Random();
    char[] password = new char[length];
    
    password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
    password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
    password[2] = specialCharacter.charAt(random.nextInt(specialCharacter.length()));
    password[3] = numbers.charAt(random.nextInt(numbers.length()));
    
    for(int i = 4; i< length; i++){
        password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
    }
    return password;
      
}   

public String registerUser(){
    System.out.println("You have been registered");
     return null;
}
   boolean loginUser() {
      
      
      System.out.println("You have logged successfully");
      return false;
      
  }
  public String returnLoginStatus(boolean Login){
      if (Login = true){
          System.out.println("Successful login");
      }else{
          System.out.println("Failed login");
      }
     return null;
      
  }
      
}



        
    

