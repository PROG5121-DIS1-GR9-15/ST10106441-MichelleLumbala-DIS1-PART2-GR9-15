/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login_and_register;
import javax.swing.JOptionPane;
import javax.swing.JFrame;

/**
 *
 * @author Michelle
 */
public class Task {
    
    //checking the task description method
 boolean checkTaskDescription(String taskDescription){
     JFrame parent = new JFrame();
        JOptionPane.showMessageDialog(parent, "This method ensures that the task description is not more than 50 characters");
            
    
    if (taskDescription.length()<= 50)
        
    {
        return true;
    }
    else 
    JOptionPane.showMessageDialog(parent, "Please enter a task description of less than 50 characters");
    return false;
    
    }
         //create task method
    public String createTaskID(String taskName, int taskNumber, String developerName){
        JFrame parent = new JFrame();
        JOptionPane.showMessageDialog(parent, "This method creates and returns the taskID");
            
     return null;
}
        //pinting the task details
    public String printTaskDetails(){
        JFrame parent = new JFrame();
        JOptionPane.showMessageDialog(parent, "This method returns the task full task details of each task");
            
     return null;
    
}
       //returning the total hours
     int returnTotalHours(){
         JFrame parent = new JFrame();
        JOptionPane.showMessageDialog(parent, "This methodbreturns the total combined hours of allentered hours");
            
    return 0;
    
}
     private void createMenu(){
         
        {
         }
     }
}
